 
// export const Base_Url = 'http://192.168.2.40:8001/'
// export const Image_Url = 'http://192.168.2.40:8001'; 



export const Custom_CSS = "http://157.245.218.104:8000/'media/uploadedcss/uploaded_css_file.css" ;



 export const Base_Url = 'http://157.245.218.104:8000/';      
 export const Image_Url = 'http://157.245.218.104:8000'; 

//  export const Base_Url = 'http://192.168.2.111:8001/';      
//  export const Image_Url = 'http://192.168.2.111:8001'; 


//  export const Base_Url = 'http://192.168.2.95:8001/';      
//  export const Image_Url = 'http://192.168.2.95:8001';  
 

// export const Base_Url = 'http://192.68.2.111:8001/'
// export const Image_Url = 'http://192.68.2.111:8001'; 
 
 
 //Live server

// export const Base_Url = 'http://68.183.133.217:8000/';    
// export const Image_Url = 'http://68.183.133.217:8000';   


//local Server

//  export const Base_Url = 'http://192.168.2.95:8000/';      
//  export const Image_Url = 'http://192.168.2.95:8000';  

 export const AppVersion = '1.1' ;
 export const accessToken = '11' ;


//  Skype: 
//  netset.tallent50
//  V9eSL>P/j#h<]

