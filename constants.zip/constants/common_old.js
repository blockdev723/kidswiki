//  export const Base_Url = 'http://192.168.2.95:8000/';
 export const Base_Url = 'http://68.183.133.217:8000/';


export const AppVersion = '1.1';


